from glob import glob
from setuptools import find_packages, setup


package_name = 'cup_mouse_detector'

setup(
    name=package_name,
    version='1.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', glob('launch/*.launch.py')),
        ('share/' + package_name + '/config', glob('config/*.yaml')),
        ('share/' + package_name + '/models', glob('models/*')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='student',
    maintainer_email='student@example.com',
    description='YOLO cup and computer-mouse detector for Jetson and ROS 2.',
    license='Apache-2.0',
    entry_points={
        'console_scripts': [
            'detector_node = cup_mouse_detector.detector_node:main',
            'demo_publisher = cup_mouse_detector.demo_publisher:main',
        ],
    },
)

