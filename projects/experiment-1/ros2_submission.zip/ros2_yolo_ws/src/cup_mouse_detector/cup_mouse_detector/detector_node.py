#!/usr/bin/env python3
"""YOLO camera detector and ROS 2 JSON publisher."""

import json
from pathlib import Path
from time import perf_counter

import cv2
import rclpy
from ament_index_python.packages import get_package_share_directory
from cv_bridge import CvBridge
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import Float32, String
from ultralytics import YOLO


class CupMouseDetector(Node):
    """Run YOLO on camera frames and publish structured detection results."""

    def __init__(self) -> None:
        super().__init__('cup_mouse_detector')

        self.declare_parameter('model_path', '')
        self.declare_parameter('camera_id', 0)
        self.declare_parameter('confidence_threshold', 0.50)
        self.declare_parameter('image_size', 640)
        self.declare_parameter('device', '0')
        self.declare_parameter('show_window', True)
        self.declare_parameter('publish_annotated_image', True)
        self.declare_parameter('save_video', False)
        self.declare_parameter('output_video', 'detection_result.mp4')

        model_path = self.get_parameter('model_path').value
        if not model_path:
            share_dir = Path(get_package_share_directory('cup_mouse_detector'))
            model_path = str(share_dir / 'models' / 'best.pt')

        self.confidence = float(self.get_parameter('confidence_threshold').value)
        self.image_size = int(self.get_parameter('image_size').value)
        self.device = str(self.get_parameter('device').value)
        self.show_window = bool(self.get_parameter('show_window').value)
        self.publish_image = bool(self.get_parameter('publish_annotated_image').value)
        self.save_video = bool(self.get_parameter('save_video').value)
        self.output_video = str(self.get_parameter('output_video').value)

        if not Path(model_path).is_file():
            raise FileNotFoundError(f'YOLO weight file not found: {model_path}')

        self.get_logger().info(f'Loading model: {model_path}')
        self.model = YOLO(model_path)

        camera_id = int(self.get_parameter('camera_id').value)
        self.capture = cv2.VideoCapture(camera_id)
        if not self.capture.isOpened():
            raise RuntimeError(f'Cannot open camera {camera_id}')

        self.bridge = CvBridge()
        self.video_writer = None
        self.detection_pub = self.create_publisher(
            String, '/object_detector/detections', 10)
        self.fps_pub = self.create_publisher(
            Float32, '/object_detector/fps', 10)
        self.image_pub = self.create_publisher(
            Image, '/object_detector/annotated_image', 10)
        self.timer = self.create_timer(0.01, self.process_frame)
        self.get_logger().info('Detector started. Press q in the image window to stop.')

    def process_frame(self) -> None:
        ok, frame = self.capture.read()
        if not ok:
            self.get_logger().warning('Camera frame read failed.')
            return

        started = perf_counter()
        result = self.model.predict(
            source=frame,
            conf=self.confidence,
            imgsz=self.image_size,
            device=self.device,
            verbose=False,
        )[0]
        inference_ms = (perf_counter() - started) * 1000.0
        fps = 1000.0 / inference_ms if inference_ms > 0.0 else 0.0

        stamp = self.get_clock().now().to_msg()
        detections = []
        if result.boxes is not None:
            for box in result.boxes:
                class_id = int(box.cls[0].item())
                confidence = float(box.conf[0].item())
                xmin, ymin, xmax, ymax = [
                    int(value) for value in box.xyxy[0].tolist()
                ]
                detections.append({
                    'class_id': class_id,
                    'class_name': str(result.names[class_id]),
                    'confidence': round(confidence, 4),
                    'bbox': {
                        'xmin': xmin,
                        'ymin': ymin,
                        'xmax': xmax,
                        'ymax': ymax,
                    },
                })

        payload = {
            'timestamp': {'sec': stamp.sec, 'nanosec': stamp.nanosec},
            'frame_id': 'camera',
            'image_width': int(frame.shape[1]),
            'image_height': int(frame.shape[0]),
            'inference_ms': round(inference_ms, 2),
            'fps': round(fps, 2),
            'detection_count': len(detections),
            'detections': detections,
        }
        message = String()
        message.data = json.dumps(payload, ensure_ascii=False)
        self.detection_pub.publish(message)

        fps_message = Float32()
        fps_message.data = float(fps)
        self.fps_pub.publish(fps_message)

        annotated = result.plot()
        cv2.putText(
            annotated,
            f'FPS: {fps:.1f}',
            (10, 30),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (0, 255, 0),
            2,
        )

        if self.publish_image:
            image_message = self.bridge.cv2_to_imgmsg(annotated, encoding='bgr8')
            image_message.header.stamp = stamp
            image_message.header.frame_id = 'camera'
            self.image_pub.publish(image_message)

        if self.save_video:
            self._write_video(annotated)

        if self.show_window:
            cv2.imshow('Cup and Mouse Detection', annotated)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                self.get_logger().info('Stop requested from image window.')
                rclpy.shutdown()

    def _write_video(self, frame) -> None:
        if self.video_writer is None:
            height, width = frame.shape[:2]
            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            self.video_writer = cv2.VideoWriter(
                self.output_video, fourcc, 20.0, (width, height))
            if not self.video_writer.isOpened():
                raise RuntimeError(f'Cannot create video: {self.output_video}')
            self.get_logger().info(f'Saving result video to: {self.output_video}')
        self.video_writer.write(frame)

    def destroy_node(self) -> bool:
        if hasattr(self, 'capture'):
            self.capture.release()
        if self.video_writer is not None:
            self.video_writer.release()
        cv2.destroyAllWindows()
        return super().destroy_node()


def main(args=None) -> None:
    rclpy.init(args=args)
    node = None
    try:
        node = CupMouseDetector()
        rclpy.spin(node)
    except (FileNotFoundError, RuntimeError) as error:
        if node is not None:
            node.get_logger().fatal(str(error))
        else:
            print(f'[cup_mouse_detector] {error}')
    except KeyboardInterrupt:
        pass
    finally:
        if node is not None:
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()

