"""ROS 2 cup and mouse detector package."""

