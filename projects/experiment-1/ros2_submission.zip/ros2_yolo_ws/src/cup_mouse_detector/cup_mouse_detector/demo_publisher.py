#!/usr/bin/env python3
"""Publish fake detection data so the ROS interface can be tested without a camera."""

import json

import rclpy
from rclpy.node import Node
from std_msgs.msg import String


class DemoPublisher(Node):
    def __init__(self) -> None:
        super().__init__('cup_mouse_demo_publisher')
        self.publisher = self.create_publisher(
            String, '/object_detector/detections', 10)
        self.timer = self.create_timer(1.0, self.publish_demo)
        self.counter = 0

    def publish_demo(self) -> None:
        stamp = self.get_clock().now().to_msg()
        class_id = self.counter % 2
        class_name = 'mouse' if class_id == 0 else 'cup'
        payload = {
            'timestamp': {'sec': stamp.sec, 'nanosec': stamp.nanosec},
            'frame_id': 'camera',
            'image_width': 640,
            'image_height': 480,
            'inference_ms': 25.0,
            'fps': 40.0,
            'detection_count': 1,
            'detections': [{
                'class_id': class_id,
                'class_name': class_name,
                'confidence': 0.95,
                'bbox': {'xmin': 100, 'ymin': 80, 'xmax': 300, 'ymax': 260},
            }],
        }
        message = String()
        message.data = json.dumps(payload, ensure_ascii=False)
        self.publisher.publish(message)
        self.get_logger().info(f'Published demo detection: {class_name}')
        self.counter += 1


def main(args=None) -> None:
    rclpy.init(args=args)
    node = DemoPublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()

