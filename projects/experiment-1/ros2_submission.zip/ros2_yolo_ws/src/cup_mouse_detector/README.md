# 杯子与鼠标检测 ROS 2 功能包

本功能包在摄像头画面上运行 YOLO，实时显示类别、边界框、置信度与 FPS，并通过 ROS 2 发布检测结果、FPS 和标注图像。已随包放入本实验训练得到的 `models/best.pt`。

## 发布话题

| 话题 | 消息类型 | 内容 |
|---|---|---|
| `/object_detector/detections` | `std_msgs/msg/String` | JSON：时间戳、类别、置信度、边界框、推理时间 |
| `/object_detector/fps` | `std_msgs/msg/Float32` | 实时 FPS |
| `/object_detector/annotated_image` | `sensor_msgs/msg/Image` | 绘制检测框后的图像 |

JSON 中每个检测目标的格式：

```json
{
  "timestamp": {"sec": 123, "nanosec": 456},
  "detections": [
    {
      "class_id": 1,
      "class_name": "cup",
      "confidence": 0.9321,
      "bbox": {"xmin": 100, "ymin": 80, "xmax": 300, "ymax": 260}
    }
  ]
}
```

## Jetson 环境准备

以下命令以 ROS 2 Humble 为例。本权重已经使用 Ultralytics 8.4.127 成功加载和推理。先安装与 JetPack 匹配的 NVIDIA PyTorch，再将 Ultralytics 安装到 **ROS 2 节点实际使用的同一个 Python 环境**；不要让 `pip` 自动覆盖 Jetson 专用的 PyTorch。

```bash
sudo apt update
sudo apt install ros-humble-cv-bridge python3-opencv python3-colcon-common-extensions
python3 -m pip install "ultralytics>=8.4.127" --no-deps
```

确认 Python 能导入依赖：

```bash
python3 -c "import torch, ultralytics, cv2; print(torch.cuda.is_available())"
```

## 编译

```bash
cd ~/ros2_yolo_ws
source /opt/ros/humble/setup.bash
colcon build --symlink-install
source install/setup.bash
```

## 无相机快速验收

终端一：

```bash
source ~/ros2_yolo_ws/install/setup.bash
ros2 launch cup_mouse_detector detector.launch.py use_demo:=true
```

终端二：

```bash
source ~/ros2_yolo_ws/install/setup.bash
ros2 topic echo /object_detector/detections
```

应当每秒收到一条轮流包含 `mouse`、`cup` 的测试消息。

## 运行真实检测

```bash
source ~/ros2_yolo_ws/install/setup.bash
ros2 launch cup_mouse_detector detector.launch.py
```

按 `q` 关闭显示窗口。参数位于 `config/detector.yaml`。若要保存验收视频，将 `save_video` 改为 `true`，或执行：

```bash
ros2 run cup_mouse_detector detector_node --ros-args \
  -p save_video:=true \
  -p output_video:=/home/jetson/detection_result.mp4
```

无显示器运行时：

```bash
ros2 run cup_mouse_detector detector_node --ros-args -p show_window:=false
```

## 验收命令

```bash
ros2 node list
ros2 topic list
ros2 topic type /object_detector/detections
ros2 topic hz /object_detector/detections
ros2 topic echo /object_detector/detections
```

## 类别编号说明

本次训练数据集的类别映射为：

```text
0: mouse
1: cup
```

节点直接使用 `best.pt` 内保存的类别名称和编号。也可运行以下命令再次确认：

```bash
python3 -c "from ultralytics import YOLO; print(YOLO('src/cup_mouse_detector/models/best.pt').names)"
```
