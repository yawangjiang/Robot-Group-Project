"""Launch the real YOLO detector or the dependency-light demo publisher."""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition, UnlessCondition
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description() -> LaunchDescription:
    use_demo = LaunchConfiguration('use_demo')
    config_file = PathJoinSubstitution([
        FindPackageShare('cup_mouse_detector'), 'config', 'detector.yaml'
    ])

    return LaunchDescription([
        DeclareLaunchArgument(
            'use_demo', default_value='false',
            description='Publish fake results without loading camera/YOLO'),
        Node(
            package='cup_mouse_detector',
            executable='detector_node',
            name='cup_mouse_detector',
            output='screen',
            parameters=[config_file],
            condition=UnlessCondition(use_demo),
        ),
        Node(
            package='cup_mouse_detector',
            executable='demo_publisher',
            name='cup_mouse_demo_publisher',
            output='screen',
            condition=IfCondition(use_demo),
        ),
    ])

